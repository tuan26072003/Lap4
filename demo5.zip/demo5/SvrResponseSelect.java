package com.hnq40.myapplication.demo5;

public class SvrResponseSelect {//GET
    private Prod[] products;
    private String message;

    public Prod[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
